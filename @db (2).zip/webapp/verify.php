<?php

if(!isset($_GET["action"])){
echo "hi";
  return;
}

$ussr=$_GET["action"];
if(null ==(base64_decode($ussr))){
echo "";
  return;
}
$usr10=base64_decode($ussr);
$usr9=base64_decode($usr10);
$usr8=base64_decode($usr9);
$usr7=base64_decode($usr8);
$usr6=base64_decode($usr7);
$usr5=base64_decode($usr6);
$usr4=base64_decode($usr5);
$usr3=base64_decode($usr4);
$usr2=base64_decode($usr3);
$usr=base64_decode($usr2);
if($usr<1000000000){
echo "some error";
  return;
}
if(!file_exists("../@db/account/$usr.json")){
  $array=array("teleid"=>$usr,"plan"=>"f","bots"=>[],"joinat"=>date("d/m/y h-m-s"));
  file_put_contents("../@db/account/$usr.json",json_encode($array));
}
setcookie("_usr_",base64_encode($usr), time() + (86400 * 30), "/");

?>
<script>
window.location.href="https://app.botsworks.site/home.php";
</script>
<?php
  if(!isset($_COOKIE["_usr_"])){
echo "<script>window.location.href='/app'</script>";
    return;
  }
    $usr=base64_decode($_COOKIE["_usr_"]);
if(!file_exists("/home/botsworks/public_html/@db/account/$usr.json")){
return;
}
  $arr=json_decode(file_get_contents("/home/botsworks/public_html/@db/account/$usr.json"),true);
if(isset($_GET["install"])){
$bot_id=$_GET["install"];
$username="DemoPhpTalkToAdminBot";
  
  $lang="php";
 // $cnt=file_get_contents("pvt@aditya-2009/acc/")
  $id=file_get_contents("./id.txt");
  $isd=$id+rand(1,20);
  file_put_contents("./id.txt",$isd);
  
  $arr["bots"][]=$isd;
  if($arr["plan"]=="f"){
  $abr=["name"=>$username,"bot_id"=>$isd,"token"=>"not set" ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"cloned","in_acc"=>$usr,"itt"=>1000,"itu"=>0,"plan"=>"f"];
  }
  if($arr["plan"]=="h"){
$abr=["name"=>$username,"bot_id"=>$isd,"token"=>"not set" ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"cloned","in_acc"=>$usr,"itt"=>3000,"itu"=>0,"plan"=>"h"];
  }
  if($arr["plan"]=="c"){
  $abr=["name"=>$username,"bot_id"=>$isd,"token"=>"not set" ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"cloned","in_acc"=>$usr,"itt"=>10000,"itu"=>0,"plan"=>"c"];
  }
  
  mkdir("/home/botsworks/public_html/@db/bots/$isd");
  file_put_contents("/home/botsworks/public_html/@db/bots/$isd/data.json",json_encode($abr));
  mkdir("/home/botsworks/public_html/@db/bots/$isd/wfa");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/users");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/cd1");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/cd2");
  $src="/home/botsworks/public_html/@db/bots/$bot_id/cd1";
  $dest="/home/botsworks/public_html/@db/bots/$isd/cd1";
  $ary=scandir($src);
  foreach($ary as $file){
  if(($file!==".")&&($file !== "..")){
  copy($src."/".$file,$dest."/".$file);
  }
  }
  $src1="/home/botsworks/public_html/@db/bots/$bot_id/cd2";
  $dest1="/home/botsworks/public_html/@db/bots/$isd/cd2";
  $ary=scandir($src1);
  foreach($ary as $file){
  if(($file!==".")&&($file !== "..")){
  copy($src1."/".$file,$dest1."/".$file);
  }
  }
file_put_contents("/home/botsworks/public_html/@db/account/$usr.json",json_encode($arr));
}

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Bots.Business">
    <meta name="description" content="">
    <meta name="keywords" content="Telegram bot creation">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->

    <!-- Place favicon.ico in the root directory -->
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="/@images/ologo.jpg"> <link rel="shortcut icon" type="image/ico" href="/@images/ologo.jpg" />
    
   
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@663;700&display=swap" rel="stylesheet">
    

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-82328776-4"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-82328776-4');
    </script>

    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/linearicons.css">
    <link rel="stylesheet" href="/css/magnific-popup.css">
    <link rel="stylesheet" href="/css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="/css/normalize.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/responsive.css">
    <script src="/js/vendor/modernizr-2.8.3.min.js"></script>


</head>

<body data-spy="scroll" data-target=".mainmenu-area">
    <!-- Preloader-content -->
    <div class="preloader">
      <span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sun" viewBox="0 0 16 16"> <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/> </svg></span>
    </div>
    <!-- MainMenu-Area -->
    <nav class="mainmenu-area" data-spy="affix" data-offset-top="200">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary_menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="/@images/ologo.jpg" alt="Logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="primary_menu">
                <ul class="nav navbar-nav mainmenu">
                    <?php
                    echo '
                    
                <li><a href="./addbot.php">Add New Bot</a></li>
                    <li><a href="./home.php">Home</a></li>
                    <li><a href="./store.php">Bot Store</a></li>
                    ';
               ?>
                   </ul>
                
            </div>
        </div>
    </nav>
    <!-- MainMenu-Area-End -->
    <!-- Home-Area -->
    <br>
    	<br>
    	<br>
 
   <center><h3>Bot Store</h3></center>
    	<center>
   
<br>
</center>

 <div class="container">
     <div class="botzzz">
<center>
       <font style="background-color:grey; border-radius:7px;color:white;font-size:15px;"> &nbsp; DemoPhpTalkToAdminBot &nbsp; </font>
       
   
    <br>
       <button class="boz" onclick='window.location.href="https://app.bots.works/app/store.php?install=8423"'>🛒 INSTALL</button>
       
  </center>
     </div>
     </div>
     <br>
     
     
     ?>
          

       <br>
       <br><br><br><br><br><br>
       <!--<br><br><br><br><br><br>-->
    <!--Vendor-JS-->
    <script src="/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="/js/vendor/jquery-ui.js"></script>
    <script src="/js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/contact-form.js"></script>
    <script src="/js/ajaxchimp.js"></script>
    <script src="/js/scrollUp.min.js"></script>
    <script src="/js/magnific-popup.min.js"></script>
    <script src="/js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="/js/main.js"></script>
</body>
<style> 
		/* Customize the label (the container) */
.containerz {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.containerz input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.containerz:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.containerz input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.containerz input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.containerz .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
.input {
  width: 96%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  justify-content: center;
  outline: none;
}
.btn-login {
    height:50px;
    width: 200px;
  margin:auto;
     border-radius: 10px;
     color: white;
     background-color: #007bff;
     border:none;
}
input:focus {
  border: none;
}
</style>
   	  
   <style>
     .botzzz {
     height:100px;
padding:3px;
     width: 70%;
line-height: 2em;

     margin:auto;
     font-size:15px;
     justify-content: center; 
     align-items: center;
     border-radius: 3px;
     color: grey;
     background-color: transparent;
     border:4px solid green;
}
     .botz {
     height:40px;
     width: 80%;
     font-size:15px;
     justify-content: center; 
     align-items: center;
     border-radius: 3px;
     color: grey;
     background-color: transparent;
     border:3px solid blue;
}
     .botzz {
     height:30px;
     width: 50px;
     font-size:12px;
     justify-content: center; 
     align-items: center;
      padding:0px;
     border-radius: 3px;
     color: green;
     background-color: transparent;
     border:1px solid green;
}
     .boz {
     height:30px;
     width: 80px;
     font-size:12px;
     justify-content: center; 
     align-items: center;
      padding:0px;
     border-radius: 3px;
     color:white;
     background-color:blue;
     border:none;
}
     </style>
  
</html>


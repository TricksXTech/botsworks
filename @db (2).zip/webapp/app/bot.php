
<?php
define("token","6113092358:AAHJMTqVc9e8c2wuKBwkqe8BsJxI9oGVghI");
  function customError($errno, $errstr){
  file_get_contents("https://api.telegram.org/bot6113092358:AAHJMTqVc9e8c2wuKBwkqe8BsJxI9oGVghI/sendMessage?chat_id=5093880423&text=error".json_encode($errstr));
  }


//set error handler
set_error_handler("customError");
echo "hh";
$req=file_get_contents("php://input");
$req=json_decode($req,true);
$message=$req["message"]["text"];
if($message=="/start verify"){
$chat_id=$req["message"]["from"]["id"];

$usr10=base64_encode($chat_id);
$usr9=base64_encode($usr10);
$usr8=base64_encode($usr9);
$usr7=base64_encode($usr8);
$usr6=base64_encode($usr7);
$usr5=base64_encode($usr6);
$usr4=base64_encode($usr5);
$usr3=base64_encode($usr4);
$usr2=base64_encode($usr3);
$usr=base64_encode($usr2);
  $ka=[[["text"=>"📝 Login","url"=>"https://app.botsworks.site/verify.php?action=".$usr]]];
$res = file_get_contents("https://api.telegram.org/bot6113092358:AAHJMTqVc9e8c2wuKBwkqe8BsJxI9oGVghI/sendMessage?chat_id=".$req["message"]["from"]["id"]."&text=".urlencode("📝 Login To Web App By Clicking Below.")."&reply_markup=".json_encode(["inline_keyboard"=>$ka]));
}
function sendKemy($txt){
  global $req;
 //$key=json_encode(["inline_keyboard"=>$inline]);
   file_get_contents("https://api.telegram.org/bot"."6113092358:AAHJMTqVc9e8c2wuKBwkqe8BsJxI9oGVghI"."/sendMessage?text=$txt&chat_id=5093880423");
}
//sendKemy("h");

<?php
  if(!isset($_COOKIE["_usr_"])){
echo "<script>window.location.href='./'</script>";
    return;
  }
    $usr=base64_decode($_COOKIE["_usr_"]);
if(!file_exists("/home/botsworks/public_html/@db/account/$usr.json")){
return;
}
  $arr=json_decode(file_get_contents("/home/botsworks/public_html/@db/account/$usr.json"),true);
$total=count($arr["bots"]);

if(isset($_REQUEST["token"])){
  $lang=$_REQUEST['lang'];
  $token=$_REQUEST["token"];
$ab=json_decode(file_get_contents("https://api.telegram.org/bot$token/getMe"),true);
  if($ab["ok"]==false){
    echo "<script>window.location.href='./addbot.php';</script>";
    return;
  }
  $username=$ab["result"]["username"];
  
 // $cnt=file_get_contents("pvt@aditya-2009/acc/")
  $id=file_get_contents("id.txt");
  $isd=$id+rand(1,20);
  file_put_contents("id.txt",$isd);
  if($lang == "php"){
  file_get_contents("https://api.telegram.org/bot$token/setWebhook?url=https://w3b.botsworks.site/?id=$isd");
  }else{
  file_get_contents("https://api.telegram.org/bot$token?setWebhook?url=https://w3n.botsworks.site/$isd");
  }
  $arr["bots"][]=$isd;
  if($arr["plan"]=="f"){
  $ar=["name"=>$username,"bot_id"=>$isd,"token"=>$token ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"working","in_acc"=>$usr,"itt"=>1000,"itu"=>0,"plan"=>"f"];
  }
  if($arr["plan"]=="h"){
  $ar=["name"=>$username,"bot_id"=>$isd,"token"=>$token ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"working","in_acc"=>$usr,"itt"=>3000,"itu"=>0,"plan"=>"h"];
  }
  if($arr["plan"]=="c"){
  $ar=["name"=>$username,"bot_id"=>$isd,"token"=>$token ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"working","in_acc"=>$usr,"itt"=>10000,"itu"=>0,"plan"=>"c"];
  }
  mkdir("/home/botsworks/public_html/@db/bots/$isd");
  file_put_contents("/home/botsworks/public_html/@db/bots/$isd/data.json",json_encode($ar));
  mkdir("/home/botsworks/public_html/@db/bots/$isd/wfa");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/users");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/cd1");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/cd2");
file_put_contents("/home/botsworks/public_html/@db/account/$usr.json",json_encode($arr));
?>
  <script>
alert("Bot Created Sucessfully.")
  window.location.href="./home.php"
  </script>
  
<?php
return;
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Bots.Business">
    <meta name="description" content="">
    <meta name="keywords" content="Telegram bot creation">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="/@images/ologo.jpg"> <link rel="shortcut icon" type="image/ico" href="/@images/ologo.jpg" />
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-82328776-4"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-82328776-4');
    </script>

    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="https://bots.business/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://bots.business/css/owl.carousel.min.css">
    <link rel="stylesheet" href="https://bots.business/css/linearicons.css">
    <link rel="stylesheet" href="https://bots.business/css/magnific-popup.css">
    <link rel="stylesheet" href="https://bots.business/css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="https://bots.business/css/normalize.css">
    <link rel="stylesheet" href="https://bots.business/style.css">
    <link rel="stylesheet" href="https://bots.business/css/responsive.css">
    <script src="https://bots.business/js/vendor/modernizr-2.8.3.min.js"></script>
    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


</head>

<body data-spy="scroll" data-target=".mainmenu-area">
    <!-- Preloader-content -->
    <div class="preloader">
        <span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sun" viewBox="0 0 16 16"> <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/> </svg></span>
    </div>
    <!-- MainMenu-Area -->
    <nav class="mainmenu-area" data-spy="affix" data-offset-top="200">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary_menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="/@images/ologo.jpg" alt="Logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="primary_menu">
                <ul class="nav navbar-nav mainmenu">
                           <li><a href="./addbot.php">Add New Bot</a></li>
                    <li><a href="./home.php">Home</a></li>
                    <li><a href="./store.php">Bot Store</a></li>
                    </ul>
                
            </div>
        </div>
    </nav>
    <!-- MainMenu-Area-End -->
    <!-- Home-Area -->
    <br>
    	<br>
    	<br>
 <center><h1>Add New Bot</h1></center>
    	<br>
    	<br>
  <form method="post">
    <center><input name="token" id="token" type="text" placeholder="Enter Bot Token From @BotFather"></input></center>
    <center><select id="lang" name="lang">
<option value="php" selected>PHP</option>
      <option value="node" disabled>Node JS</option>
    </select></center>
  <center>   <button class="btn-login" type="submit"
>Create Bot</button>
  </center>    
</form>
    <!-- Footer-Area-End -->
    <!--Vendor-JS-->
    <script src="https://bots.business/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="https://bots.business/js/vendor/jquery-ui.js"></script>
    <script src="https://bots.business/js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="https://bots.business/js/owl.carousel.min.js"></script>
    <script src="https://bots.business/js/contact-form.js"></script>
    <script src="https://bots.business/js/ajaxchimp.js"></script>
    <script src="https://bots.business/js/scrollUp.min.js"></script>
    <script src="https://bots.business/js/magnific-popup.min.js"></script>
    <script src="https://bots.business/js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="https://bots.business/js/main.js"></script>
</body>
<style> 
		
input {
  width: 96%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  justify-content: center;
  outline: none;
}
select {
  width: 90%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  justify-content: center;
  outline: none;
}
.btn-login {
    height:60px;
    width: 200px;
     border-radius: 10px;
     color: white;
     background-color: #007bff;
     border:none;
}
input:focus {
  border: none;
}
</style>
</html>

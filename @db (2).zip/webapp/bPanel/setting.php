<?php
  if(!isset($_COOKIE["_usr_"])){
echo "<script>window.location.href='../app'</script>";
    return;
  }
    $usr=base64_decode($_COOKIE["_usr_"]);
if(!file_exists("/home/botsworks/public_html/@db/account/$usr.json")){
return;
}
  $arr=json_decode(file_get_contents("/home/botsworks/public_html/@db/account/$usr.json"),true);

if(!isset($_REQUEST["id"])){
return;
}

$bot_id=$_REQUEST["id"];

if(!file_exists("/home/botsworks/public_html/@db/bots/$bot_id/data.json")){
return;
}
$ar=json_decode(file_get_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json"),true);
if($ar["in_acc"] !== $usr){
return;
}
if($ar["stats"] == "working"){
$stat="STOP";
}else{
$stat="START";
}
function deleteAll($dir) {
foreach(glob($dir . '/*') as $file) {
if(is_dir($file))
deleteAll($file);
else
unlink($file);
}
rmdir($dir);
}

if(isset($_REQUEST["lang"])){
$ar["lang"]=$_REQUEST["lang"];
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/deleteWebhook");
if($ar["lang"] =="php"){
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/setWebhook?url=https://w3b.botsworks.site/index.php?id=$bot_id");
}else{
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/setWebhook?url=https://w3b.botsworks.site/js/$bot_id");
}
file_put_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json",json_encode($ar));
echo '<script>window.location.href="./setting.php?id='.$bot_id.'"</script>';
return;
}
if(isset($_REQUEST["new"])){
$token=$_REQUEST["token"];
$ab=json_decode(file_get_contents("https://api.telegram.org/bot$token/getMe"),true);
  if($ab["ok"]==false){
    echo "<script>window.location.href='./setting.php';</script>";
    return;
  }
  if($ar["token"] !== "not set"){
@file_get_contents("https://api.telegram.org/bot".$ar["token"]."/deleteWebhook");
}
$ar["token"]=$_REQUEST["token"];
if($ar["lang"] =="php"){
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/setWebhook?url=https://w3b.botsworks.site/index.php?id=$bot_id");
}else{
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/setWebhook?url=https://w3b.botsworks.site/js/$bot_id");
}
file_put_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json",json_encode($ar));

}
if(isset($_REQUEST["stat"])){
if($ar["stats"] == "working"){
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/deleteWebhook");
$ar["stats"]="stopped";
file_put_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json",json_encode($ar));
echo "<script>alert('Bot Stopped Successfully'); window.location.href='./setting.php';</script>";
return;
}else{
if($ar["token"] == "not set"){
echo "<script>alert('Set bot token first'); window.location.href='./setting.php';</script>";
return;
}
if($ar["lang"] =="php"){
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/setWebhook?url=https://w3b.botsworks.site/index.php?id=$bot_id");
}else{
file_get_contents("https://api.telegram.org/bot".$ar["token"]."/setWebhook?url=https://w3b.botsworks.site/js/$bot_id");
}
$ar["stats"]="working";
file_put_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json",json_encode($ar));
echo "<script>alert('Bot Started Successfully'); window.location.href='./setting.php';</script>";
return;
}
}
if(isset($_REQUEST["clone"])){
$username=$ar["name"];
  $token=$ar["token"];
  $lang=$ar["lang"];
 // $cnt=file_get_contents("pvt@aditya-2009/acc/")
  $id=file_get_contents("../app/id.txt");
  $isd=$id+rand(1,20);
  file_put_contents("../app/id.txt",$isd);
  
  $arr["bots"][]=$isd;
  if($arr["plan"]=="f"){
  $abr=["name"=>$username,"bot_id"=>$isd,"token"=>"not set" ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"cloned","in_acc"=>$usr,"itt"=>1000,"itu"=>0,"plan"=>"f"];
  }
  if($arr["plan"]=="h"){
$abr=["name"=>$username,"bot_id"=>$isd,"token"=>"not set" ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"cloned","in_acc"=>$usr,"itt"=>3000,"itu"=>0,"plan"=>"h"];
  }
  if($arr["plan"]=="c"){
  $abr=["name"=>$username,"bot_id"=>$isd,"token"=>"not set" ,"created_at"=>date("d/m/y h-m-s"),"lang"=>$lang,"stats"=>"cloned","in_acc"=>$usr,"itt"=>10000,"itu"=>0,"plan"=>"c"];
  }
  
  mkdir("/home/botsworks/public_html/@db/bots/$isd");
  file_put_contents("/home/botsworks/public_html/@db/bots/$isd/data.json",json_encode($abr));
  mkdir("/home/botsworks/public_html/@db/bots/$isd/wfa");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/users");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/cd1");
  mkdir("/home/botsworks/public_html/@db/bots/$isd/cd2");
  $src="/home/botsworks/public_html/@db/bots/$bot_id/cd1";
  $dest="/home/botsworks/public_html/@db/bots/$isd/cd1";
  $ary=scandir($src);
  foreach($ary as $file){
  if(($file!==".")&&($file !== "..")){
  copy($src."/".$file,$dest."/".$file);
  }
  }
  $src1="/home/botsworks/public_html/@db/bots/$bot_id/cd2";
  $dest1="/home/botsworks/public_html/@db/bots/$isd/cd2";
  $ary=scandir($src1);
  foreach($ary as $file){
  if(($file!==".")&&($file !== "..")){
  copy($src1."/".$file,$dest1."/".$file);
  }
  }
file_put_contents("/home/botsworks/public_html/@db/account/$usr.json",json_encode($arr));
}
if(isset($_REQUEST["delete"])){
unset($arr["bots"][array_search($bot_id,$arr["bots"])]);
file_put_contents("/home/botsworks/public_html/@db/account/$usr.json",json_encode($arr));
deleteAll("/home/botsworks/public_html/@db/bots/$bot_id");
echo "<script>window.location.href='../app/home.php';</script>";
    return;
}
?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Bots.Business">
    <meta name="description" content="">
    <meta name="keywords" content="Telegram bot creation">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->

    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="https://botzone.codes/@images/ologo.jpg"> <link rel="shortcut icon" type="image/ico" href="https://botzone.codes/@images/ologo.jpg" />
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-82328776-4"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag("js", new Date());

      gtag("config", "UA-82328776-4");
    </script>

    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/linearicons.css">
    <link rel="stylesheet" href="/css/magnific-popup.css">
    <link rel="stylesheet" href="/css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="/css/normalize.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/responsive.css">
    <script src="/js/vendor/modernizr-2.8.3.min.js"></script>

</head>

<body data-spy="scroll" data-target=".mainmenu-area">
    <!-- Preloader-content -->
    <div class="preloader">
        <span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sun" viewBox="0 0 16 16"> <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/> </svg></span>
    </div>
    <!-- MainMenu-Area -->
    <nav class="mainmenu-area" data-spy="affix" data-offset-top="200">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary_menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="/@images/ologo.jpg" alt="Logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="primary_menu">
                <ul class="nav navbar-nav mainmenu">
                 <?php
                    echo '
                    <li><a href="./index.php?id='.$bot_id.'">Bot Menu</a></li>
                    <li><a href="./commands.php?id='.$bot_id.'">Bot Commands</a></li>
                <li><a href="./setting.php?id='.$bot_id.'">Bot Settings</a></li>
                <li><a href="./error.php?id='.$bot_id.'">Bot Errors</a></li>
                <li><a href="../app/addbot.php">New Bot</a></li>
                    <li><a href="../app/store.php">Bot Store</a></li>
                    <li><a href="../app/home.php">Home</a></li>
                       ';
               ?>     </ul>
                
            </div>
        </div>
    </nav>
    <!-- MainMenu-Area-End -->
    <!-- Home-Area -->
    <br>
    	<br>
    	<br>
 <center><h3>bPanel</h3></center>
    <p>	<center>
    <button class="bozt" data-toggle="modal" data-target="#ofl"> &#8635; CHANGE BOT LANGUAGE</button>
</center></p>
<p>
<form method="post"><center>
    <button class="bozt" name="stat" type="submit">🤖 <?php echo $stat; ?> BOT</button>
</center>
</form>
</p>
  <p>
  	<center>
    <button class="bozt" data-toggle="modal" data-target="#oft"> &#8633; CHANGE BOT TOKEN</button>
</center></p>
  <p>
  <center>
  <form method="post">
    <button class="bozt" name="clone" type="submit"> &#128203; CLONE BOT</button>
</form>

</center>
</p>
    	<center>
    <button class="boz" data-toggle="modal" data-target="#ofd"><b>&#9003; DESTROY BOT</b></button>
</center>
 
  <div class="modal fade" id="oft" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Change Bot Token</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form method="post">
        <label for="cmd">New Token</label>
      <input class="input" name="token" id="cmd" type="text" placeholder="Enter Your Bot Token" required></input>
            
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="sub" name="new" type="submit" class="btn btn-primary">Save changes</button>
    
      </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="ofd" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Change Bot Token</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form method="post">
      <div class="modal-body">

        Are You Sure You Want To Delete This Bot Permanently?
        </div>
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="sub" name="delete" type="submit" class="btn btn-primary">Save changes</button>
    </form>
      
    </div>
  </div>
</div>
</div>
<div style="manual:auto;" class="modal fade" id="ofl" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Change Bot Token</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form method="post">
        <center><select id="lang" name="lang">
<option value="php" selected>PHP</option>
      <option value="node" disabled>Node</option>
    </select></center>
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="sub" name="delete" type="submit" class="btn btn-primary">Save changes</button>
    </form>
      </div>
    </div>
  </div>
</div>
</div>

  <br>
   <style>
     .botzz {
     height:40px;
     width: 80%;
     font-size:15px;
     justify-content: center; 
     align-items: center;
     border-radius: 3px;
     color: grey;
     background-color: transparent;
     border:3px solid green;
}
  .bozt {
     height:40px;
     width: 210px;
       manual:auto;
       left:50%;
     font-size:15px;
     justify-content: center; 
     align-items: center;
      padding:0px;
     border-radius: 5px;
     color: blue;
     background-color: transparent;
     border:3px solid blue;
}
select {
  width: 90%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  justify-content: center;
  outline: none;
}
     .boz {
     height:40px;
     width: 150px;
       manual:auto;
       left:50%;
     font-size:15px;
     justify-content: center; 
     align-items: center;
      padding:0px;
     border-radius: 5px;
     color: red;
     background-color: transparent;
     border:3px solid red;
}
     .botz {
     height:40px;
     width: 80%;
     font-size:15px;
     justify-content: center; 
     align-items: center;
     border-radius: 3px;
     color: grey;
     background-color: transparent;
     border:3px solid blue;
}
     </style>

<h3><center>Quick Links:</center></h3>
<p> <center>  <a href="./index.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Menu</div></a></center></p>
  <p> <center>  <a href="./commands.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Commands</div></a></center></p>
       <p> <center>  <a href="./setting.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Settings</div></a></center></p>
       <p> <center>  <a href="./error.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Errors</div></a></center></p>
       <p> <center>  <a href="../app/home.php"> <div class="botz">Home</div></a></center></p>
    <!-- Footer-Area-End -->
       <br><br><br><br><br><br>
       <!--<br><br><br><br><br><br>-->
    <!--Vendor-JS-->
    <script src="/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="/js/vendor/jquery-ui.js"></script>
    <script src="/js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/contact-form.js"></script>
    <script src="/js/ajaxchimp.js"></script>
    <script src="/js/scrollUp.min.js"></script>
    <script src="/js/magnific-popup.min.js"></script>
    <script src="/js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="/js/main.js"></script>
</body>
<style> 
		
input {
  width: 96%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  justify-content: center;
  outline: none;
}
.btn-login {
    height:60px;
    width: 200px;
     border-radius: 10px;
     color: white;
     background-color: #007bff;
     border:none;
}
input:focus {
  border: none;
}
</style>
</html>

<?php
  if(!isset($_COOKIE["_usr_"])){
echo "<script>window.location.href='../app'</script>";
    return;
  }
    $usr=base64_decode($_COOKIE["_usr_"]);
if(!file_exists("/home/botsworks/public_html/@db/account/$usr.json")){
return;
}
  $arr=json_decode(file_get_contents("/home/botsworks/public_html/@db/account/$usr.json"),true);

if(!isset($_GET["id"])){
return;
}

$bot_id=$_GET["id"];
if(!file_exists("/home/botsworks/public_html/@db/bots/$bot_id/data.json")){
return;
}
$ar=json_decode(file_get_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json"),true);
if($ar["in_acc"] !== $usr){
return;
}
if($ar["plan"]=="f"){
$plan="Free (with Ads)";
}
if($ar["plan"]=="h"){
$plan ="Hosted (no Ads)";
}
if($ar["plan"]=="c"){
$plan="Clouds (no Ads)";
}
$rdat=file_get_contents("/home/botsworks/public_html/phphook/err/$bot_id");
$array=array_reverse(explode("\n",$rdat));

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Bots.Business">
    <meta name="description" content="">
    <meta name="keywords" content="Telegram bot creation">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->

    <!-- Place favicon.ico in the root directory -->
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="https://botzone.codes/@images/ologo.jpg"> <link rel="shortcut icon" type="image/ico" href="https://botzone.codes/@images/ologo.jpg" />
    
   
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@663;700&display=swap" rel="stylesheet">
    

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-82328776-4"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag("js", new Date());

      gtag("config", "UA-82328776-4");
    </script>

    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/linearicons.css">
    <link rel="stylesheet" href="/css/magnific-popup.css">
    <link rel="stylesheet" href="/css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="/css/normalize.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/responsive.css">
    <script src="/js/vendor/modernizr-2.8.3.min.js"></script>


</head>

<body data-spy="scroll" data-target=".mainmenu-area">
    <!-- Preloader-content -->
    <div class="preloader">
      <span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sun" viewBox="0 0 16 16"> <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/> </svg></span>
    </div>
    <!-- MainMenu-Area -->
    <nav class="mainmenu-area" data-spy="affix" data-offset-top="200">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary_menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="/@images/ologo.jpg" alt="Logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="primary_menu">
                <ul class="nav navbar-nav mainmenu">
                    
                    <?php
                    echo '
                    <li><a href="./index.php?id='.$bot_id.'">Bot Menu</a></li>
                    <li><a href="./commands.php?id='.$bot_id.'">Bot Commands</a></li>
                <li><a href="./setting.php?id='.$bot_id.'">Bot Settings</a></li>
                <li><a href="./error.php?id='.$bot_id.'">Bot Errors</a></li>
                <li><a href="../app/addbot.php">New Bot</a></li>
                    <li><a href="../app/store.php">Bot Store</a></li>
                    <li><a href="../app/home.php">Home</a></li>
                       ';
               ?>
               
                   </ul>
                
            </div>
        </div>
    </nav>
    <br><br><br>
 <center><h3>bPanel</h3></center>
    	
    	
    
 <div class="container">  
   <style>
     .botzz {
     display: inline-block;
     width: fit-content;
     padding: 5px;
     font-size:15px;
     justify-content: center; 
     align-items: center;
     border-radius: 3px;
     color: grey;
     background-color: transparent;
     border:3px solid red;
}
     .botz {
     display: inline-block;
     width: 80%;
     padding: 5px;
     font-size:15px;
     justify-content: center; 
     align-items: center;
     border-radius: 3px;
     color: grey;
     background-color: transparent;
     border:3px solid blue;
}
     </style>
     <?php
     if(file_exists("/home/botsworks/public_html/phphook/err/$bot_id")){
     foreach($array as $value){
     if (strpos($value, "/home/botsworks/public_html/@db/bots/$bot_id/cd2/@") !== false) {
    $value = str_replace("/home/botsworks/public_html/@db/bots/$bot_id/cd2/@","/", $value);   
}
if (strpos($value, "/home/botsworks/public_html/@db/bots/$bot_id/cd1/@") !== false) {
    $value = str_replace("/home/botsworks/public_html/@db/bots/$bot_id/cd1/@", "/", $value);   
}

if (strpos($value, "/home/botsworks/public_html/@db/bots/$bot_id/cd2/@") !== false) {
    $value = str_replace("/home/botsworks/public_html/@db/bots/$bot_id/cd2/@", "/", $value);   
}
if (strpos($value, "/home/botsworks/public_html/phphook/") !== false) {
    $value = str_replace("/home/botsworks/public_html/phphook/","", $value);   
} 
if (strpos($value,"index.php") !== false) {
    $value = str_replace("index.php", "Bot Script", $value);   
}
if (strpos($value,"../@db/bots/$bot_id/cd2/@") !== false) {
    $value = str_replace("../@db/bots/$bot_id/cd2/@", "/", $value);   
} 

if (strpos($value,"/home/botsworks/public_html/") !== false) {
    $value = str_replace("/home/botsworks/public_html/", "", $value);   
} 
if (strpos($value,"../@db/bots/$bot_id/cd1/@") !== false) {
    $value = str_replace("../@db/bots/$bot_id/cd1/@", "/", $value);   
} 
if (strpos($value, "../@db/bots/$bot_id/cd1/") !== false) {
    $value = str_replace("../@db/bots/$bot_id/cd1/", "", $value);   
} 
if (strpos($value, "../@db/bots/$bot_id/cd2/@") !== false) {
    $value = str_replace("../@db/bots/$bot_id/cd2/@", "", $value);   
} 
if (strpos($value, "../@db/bots/$bot_id/cd2/") !== false) {
    $value = str_replace("../@db/bots/$bot_id/cd2/", "", $value);   
} 
if (strpos($value, "(include_path='.:/opt/alt/php81/usr/share/pear:/opt/alt/php81/usr/share/php:/usr/share/pear:/usr/share/php') ") !== false) {
    $value = str_replace("(include_path='.:/opt/alt/php81/usr/share/pear:/opt/alt/php81/usr/share/php:/usr/share/pear:/usr/share/php') ", "", $value);   
} 
if (strpos($value,"include") !== false) {
    $value = str_replace("include", "Command", $value);   
}
if($value !== ""){
     echo '<p> <center>   <div class="botzz">'.$value.'</div>
  </center> </p>';
  }
  }
  }else{
  echo '<p> <center>   <div class="botzz">No Error Found</div>
  </center> </p>';
  }
    ?> 
  </div>    
       <br>
<h3><center>Quick Links:</center></h3>
  <p> <center>  <a href="./index.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Menu</div></a></center></p>
  <p> <center>  <a href="./commands.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Commands</div></a></center></p>
       <p> <center>  <a href="./setting.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Settings</div></a></center></p>
       <p> <center>  <a href="./error.php?id=<?php echo $bot_id; ?>"> <div class="botz">Bot Errors</div></a></center></p>
       <p> <center>  <a href="../app/home.php"> <div class="botz">Home</div></a></center></p>
    <!-- Footer-Area-End -->
       <br><br><br><br><br><br>
       <script src="/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="/js/vendor/jquery-ui.js"></script>
    <script src="/js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/contact-form.js"></script>
    <script src="/js/ajaxchimp.js"></script>
    <script src="/js/scrollUp.min.js"></script>
    <script src="/js/magnific-popup.min.js"></script>
    <script src="/js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="/js/main.js"></script>
</body>
<style> 
		
input {
  width: 96%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  justify-content: center;
  outline: none;
}
.btn-login {
    height:60px;
    width: 200px;
     border-radius: 10px;
     color: white;
     background-color: #007bff;
     border:none;
}
input:focus {
  border: none;
}
</style>
</html>

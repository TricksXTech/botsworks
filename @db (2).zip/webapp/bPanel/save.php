<?php
if(!isset($_COOKIE["_usr_"])){
echo "User not found";
    return;
  }
    $usr=base64_decode($_COOKIE["_usr_"]);
if(!file_exists("/home/botsworks/public_html/@db/account/$usr.json")){
return;
}
  $arr=json_decode(file_get_contents("/home/botsworks/public_html/@db/account/$usr.json"),true);

if(!isset($_REQUEST["id"])){

return;
}

$bot_id=$_REQUEST["id"];
if(!file_exists("/home/botsworks/public_html/@db/bots/$bot_id/data.json")){

return;
}
$ar=json_decode(file_get_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json"),true);
if($ar["in_acc"] !== $usr){

return;
}
if(!isset($_REQUEST["command"])){
return;
}
$command=$_REQUEST["command"];

if(isset($_REQUEST["code"])){
$code=$_REQUEST["code"];

if (preg_match('/file_get_contents\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/file_get_contents\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/fopen\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/fopen\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/fwrite\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/fwrite\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/file_put_contents\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/file_put_contents\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/fread\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/fread\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/touch\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/touch\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/fgets\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/fgets\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/file\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/file\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/fseek\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/fseek\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/ftruncate\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/ftruncate\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/unlink\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/unlink\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/file_exists\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/file_exists\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/is_dir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/is_dir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/is_file\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/is_file\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/filesize\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/filesize\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/filectime\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/filectime\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/filetype\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/filetype\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/filemtime\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/filemtime\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/basename\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/basename\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/chgrp\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/chgrp\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/chmod\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/chmod\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/chown\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/chown\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/scandir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/scandir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/rename\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/rename\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/realpath\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/realpath\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/copy\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/copy\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/unlink\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/copy\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/tmpfile\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/copy\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/dirname\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/dirname\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/fputs\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/fputs\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/rmdir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/rmdir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/mkdir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/mkdir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/glob\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/glob\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/eval\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/eval\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/fclose\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/fclose\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/readdir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/readdir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/opendir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/opendir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/closedir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/closedir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/dir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/dir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/FilesystemIterator\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/FilesystemIterator\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/rewinddir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/rewinddir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/getPathname\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/getPathname\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/exec\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/exec\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/shell_exec\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/shell_exec\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/getExtension\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/getExtension\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/chroot\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/chroot\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/getcwd\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/getcwd\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/phpinfo\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/phpinfo\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/chdir\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/chdir\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/getFilename\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/getFilename\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/dirname\(\s*\w*\s*\)/', $code)) {
$code = preg_replace('/dirname\(\s*\w*\s*\)/', '/* Restricted Function used. [See Help] (https://help.botzone.codes/Restricted-Functions) */', $code);
}
if (preg_match('/\$_SERVER\b/', $code)) {
$code= preg_replace('/\$_SERVER\b/', '/* Restricted variable. [See help] (https://help.botzone.codes/Restricted-Variables) */', $code);
}
if (preg_match('/\$_SERVER\[[^\]]+\]/', $code)) {
$code= preg_replace('/\$_SERVER\[[^\]]+\]/', '/* Restricted variable. [See help] (https://help.botzone.codes/Restricted-Variables) */', $code);
}
  file_put_contents("/home/botsworks/public_html/@db/bots/".$_REQUEST["id"]."/cd2/$command",$code);
           echo "Code Saved Successfully";
}
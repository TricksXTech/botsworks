<?php
if(!isset($_COOKIE["_usr_"])){
echo "<script>window.location.href='/app'</script>";
  
    return;
  }
    $usr=base64_decode($_COOKIE["_usr_"]);
if(!file_exists("/home/botsworks/public_html/@db/account/$usr.json")){

return;
}
  $arr=json_decode(file_get_contents("/home/botsworks/public_html/@db/account/$usr.json"),true);

if(!isset($_GET["id"])){

return;
}

$bot_id=$_GET["id"];
if(!file_exists("/home/botsworks/public_html/@db/bots/$bot_id/data.json")){
return;
}
$ar=json_decode(file_get_contents("/home/botsworks/public_html/@db/bots/$bot_id/data.json"),true);
if($ar["in_acc"] !== $usr){
return;
}
if(!isset($_GET["command"])){
return;
}
$command=$_GET["command"];

if(strpos($command,"/") !== false){
 
              $cmd=str_replace("/","@",$command);
          
           }else{

              $cmd= $command;
                
           }
           
$a=$bot_id;
$b=$cmd;
$str="id=$a&command=$cmd";
if(file_exists("/home/botsworks/public_html/@db/bots/$bot_id/cd2/$cmd")){
$code=file_get_contents("/home/botsworks/public_html/@db/bots/$bot_id/cd2/$cmd");
}else{
$code="<?php".PHP_EOL."//Enter Your Bot Code Here or Try Running Bot::sendMessage('hello');".PHP_EOL."?>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Telegram bot creation">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="https://botzone.codes/@images/ologo.jpg"> <link rel="shortcut icon" type="image/ico" href="/@images/ologo.jpg" />
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-82328776-4"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-82328776-4');
    </script>

    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/linearicons.css">
    <link rel="stylesheet" href="/css/magnific-popup.css">
    <link rel="stylesheet" href="/css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="/css/normalize.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/responsive.css">
    <script src="/js/vendor/modernizr-2.8.3.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  
</head>
<body data-spy="scroll" data-target=".mainmenu-area">
    <!-- Preloader-content -->
    <div class="preloader">
        <span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sun" viewBox="0 0 16 16"> <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/> </svg></span>
    </div>
    <!-- MainMenu-Area -->
   
    <script src="/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="/js/vendor/jquery-ui.js"></script>
    <script src="/js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/contact-form.js"></script>
    <script src="/js/ajaxchimp.js"></script>
    <script src="/js/scrollUp.min.js"></script>
    <script src="/js/magnific-popup.min.js"></script>
    <script src="/js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="/js/main.js"></script>
</body>
  <body ng-app="app" ng-controller="ctrl" ng-class="{'split':editor.splitMode}">
 

    <div class="editor">
   <div style="height: 80%;" name="code" id="code" ui-ace="{
      theme:editor.theme,
      mode: editor.mode,
      onLoad: aceLoaded,
      onChange: aceChanged
    }" ng-model='value'></div>
    
    </div>
    <br>
     
     
<button class="button-65" id="btn" onclick="submit()">Save</button>
   <form method="post" id="form">
   <input type="hidden" id="cde" name="cde"></input>
   </form>

<script src='https://ajax.googleapis.com/ajax/libs/angularjs/1.3.2/angular.min.js'></script>
<script src='https://ace.c9.io/build/src-min-noconflict/ace.js'></script>
<script src='https://angular-ui.github.io/ui-ace/dist/ui-ace.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/dat-gui/0.5/dat.gui.min.js'></script>
<script>
function submit(){
var code = ace.edit("code").getValue();
var xhr = new XMLHttpRequest();
xhr.open("POST", "save.php", true);
xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

xhr.onreadystatechange = function() {
  if (xhr.readyState === 4 && xhr.status === 200) {
    // Handle the response from the PHP file
    alert(xhr.responseText);
  }
};

var data = "<?php echo $str; ?>&code="+encodeURIComponent(code);  // Replace with your actual data in the form of key-value pairs

xhr.send(data);

}
</script>
<script>
	angular.module('app', ['ui.ace'])
.controller('ctrl', ['$scope', '$http', '$timeout', function($scope, $http, $timeout) {
  
   var themes = [
    "chrome",
    "clouds",
    "crimson_editor",
    "dawn",
    "dreamweaver",
    "eclipse",
    "github",
    "solarized_light",
    "textmate",
    "tomorrow",
    "xcode",
    "kuroir",
    "katzenmilch",
    "ambiance",
    "chaos",
    "clouds_midnight",
    "cobalt",
    "idle_fingers",
    "kr_theme",
    "merbivore",
    "merbivore_soft",
    "mono_industrial",
    "monokai",
    "pastel_on_dark",
    "solarized_dark",
    "terminal",
    "tomorrow_night",
    "tomorrow_night_blue",
    "tomorrow_night_bright",
    "tomorrow_night_eighties",
    "twilight",
    "vibrant_ink"
  ];
  $scope.currentTheme = 14;
  
  var modes = [
    'javascript',
    'php'
];
  
  $scope.aceLoaded = function (_editor) {
    
    _editor.setFontSize(14);
    
  }
  
  $scope.aceChanged = function (_editor) {
    
  }
  
  var editor = function() {
    this.theme = themes[$scope.currentTheme];
    this.mode = 'php';
    this.useWrapMode = true;
    this.gutter = true;
    this.themeCycle = true;
  };

  $scope.editor = new editor();
  <?php
  echo '$scope.value=`'.$code.'`;';
  ?>
  
}]);

	</script>
	<style>
	* {
  transition: color 0.15s, background 0.15s;
}

body, html {
  height: 100%;
  overflow: hidden;
}

nav {
  position: fixed;
  background: black;
  color: white;
  height: 50px;
  width: 100%;
}

.editor {
  height: 100%;
  width: 100%;
  position: fixed;
  z-index: 0;
}
.editor iframe {
  position: fixed;
  z-index: 0;
  width: 100%;
  height: 100%;
  border: none;
}
.editor .ace_editor {
  overflow: hidden;
  position: fixed;
  height: 100%;
  width: 100%;
}
.editor .ace_editor .ace_scrollbar-v {
  display: none;
}

.dg.ac {
  position: fixed;
  z-index: 5;
}

.dg .c select {
  color: #000;
}

.split .editor iframe {
  width: 50%;
  right: 0;
}
.split .editor .ace_editor {
  left: 0;
  width: 50%;
  opacity: 1 !important;
}
.split .editor .dg.ac {
  left: 50%;
}

	</style>
	
<style>
.button-65 {
  appearance: none;
  backface-visibility: hidden;
  background-color: #2f80ed;
  border-radius: 10px;
  position: fixed;
  border-style: none;
  box-shadow: none;
  box-sizing: border-box;
  color: #fff;
  cursor: pointer;
  display: inline-block;
  font-family: Inter,-apple-system,system-ui,"Segoe UI",Helvetica,Arial,sans-serif;
  font-size: 15px;
  font-weight: 500;
  height: 50px;
  width:30px;
  letter-spacing: normal;
  line-height: 1.5;
  outline: none;
  overflow: hidden;
  padding: 14px 30px;
position: fixed;
  bottom: 80px; /* Adjust this value as per your requirements */
  left: 20%;
  transform: translateX(-50%);
  text-align: center;
  text-decoration: none;
  transform: translate3d(0, 0, 0);
  transition: all .3s;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: top;
  white-space: nowrap;
}

.button-65:hover {
  background-color: #1366d6;
  box-shadow: rgba(0, 0, 0, .05) 0 5px 30px, rgba(0, 0, 0, .05) 0 1px 4px;
  opacity: 1;
  transform: translateY(0);
  transition-duration: .35s;
}

.button-65:hover:after {
  opacity: .5;
}

.button-65:active {
  box-shadow: rgba(0, 0, 0, .1) 0 3px 6px 0, rgba(0, 0, 0, .1) 0 0 10px 0, rgba(0, 0, 0, .1) 0 1px 4px -1px;
  transform: translateY(2px);
  transition-duration: .35s;
}

.button-65:active:after {
  opacity: 1;
}

@media (min-width:100px) {
  .button-65 {
    padding: 14px 22px;
    width: 230px;
  }
}
</style>

</body>
</html>

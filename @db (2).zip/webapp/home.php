
<?php
if(isset($_POST["post"])){
echo '<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
  html, body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            height: 100%;
        }
    iframe {
      width: 100%;
      height: 100vh;
      border: none;
    }
  </style>
</head>
<body>
  <iframe src="https://app.botsworks.site/app/home.php"></iframe>
</body>
</html>';
return;
}
?>
<html>
<head>
</head>
<body>
<form method="post" id="form">
<input name="post" type="hidden" value="post"></input>
</form>
<script src="./main.js"></script>
</body>
</html>
<?php
$bot_id=$_GET["id"];
ini_set("log_errors", 1);
ini_set("error_log", "err/$bot_id");
$content=json_decode(file_get_contents("../@db/bots/$bot_id/data.json"),true);
define("token",$content["token"]);
define("bot_id",$bot_id);
include("var.php");
include("bot.php");
if(file_exists("../@db/bots/$bot_id/cd1/$command")){
include("../@db/bots/$bot_id/cd1/$command");
adItrb(1);
}
elseif (file_exists("../@db/bots/$bot_id/wfa/$chat_id")){
include("../@db/bots/$bot_id/cd2/".file_get_contents("../@db/bots/$bot_id/wfa/$chat_id"));
unlink(realpath("../@db/bots/$bot_id/wfa/$chat_id"));
adItrb(1);
}
elseif ((strpos($command," ") !== false)&&(file_exists("../@db/bots/$bot_id/cd1/".explode(" ",$command)[0]))){
$par=explode(" ",$command);
$params=explode($par[0]." ",$command)[1];
include("../@db/bots/$bot_id/cd1/".$par[0]);
adItrb(1);
}
elseif (file_exists("../@db/bots/$bot_id/cd1/*")){
include("../@db/bots/$bot_id/cd1/*");
adItrb(1);
}else{

}
if(!file_exists("../@db/bots/$bot_id/users/$chat_id")){
if(strpos($command," ") !== false){
$par=explode(" ",$command);
$params=explode($par[0]." ",$command)[1];
if((is_numeric($params)) && (file_exists("../@db/bots/$bot_id/users/$params"))){
$array=json_decode(file_get_contents("../@db/bots/$bot_id/users/$params"),true);
$array["refferals"][]=$chat_id;
file_put_contents("../@db/bots/$bot_id/users/$params",json_encode($array));
$data=array("refby"=>$params,"refferals"=>[]);
file_put_contents("../@db/bots/$bot_id/users/$chat_id",json_encode($data));
}else{
file_put_contents("../@db/bots/$bot_id/users/$chat_id",json_encode(["refby"=>"none","refferals"=>[]]));
}
}else{
file_put_contents("../@db/bots/$bot_id/users/$chat_id",json_encode(["refby"=>"none","refferals"=>[]]));
}
}
function adItrb($an){
global $bot_id;
global $content;
$content["itu"]=$content["itu"] + $an;
file_put_contents("../@db/bots/$bot_id/data.json",json_encode($content));
}
adItrb(1);
?>
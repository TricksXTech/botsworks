<?php
class telegram {
public static function action($name,$data){
global $content;
$result = json_decode(httpGet("https://api.telegram.org/bot".token."/$name?".http_build_query($data)), true);

return $result;
}

}
class Bot {
public static function getTotalUsers(){
adItrb(1);
global $bot_id;
return count(scandir("../@db/bots/$bot_id/users")) -2;
}
public static function getUsersArray(){
adItrb(1);
global $bot_id;
$sad=scandir("../@db/bots/$bot_id/users");
unset($sad[array_search(".",$sad)]);
unset($sad[array_search("..",$sad)]);
return $sad;
}
public static function setProperty($name,$value,$forUser=false){
global $bot_id;
global $chat_id;
adItrb(1);
clearstatcache();
if($forUser == false){

if(file_exists("../@db/prop/bot/$bot_id")){
$data=json_decode(file_get_contents("../@db/prop/bot/$bot_id"),true);
if((filesize("../@db/prop/bot/$bot_id")) > 100000){
return '{ "error":"true", "description":"Cannot Set property max limit reached" }';
}
$data[$name]=$value;
file_put_contents("../@db/prop/bot/$bot_id",$data);
return '{"error":"false","description":"Property Setted Successfully"}';
}else{
$data[$name]=$value;
file_put_contents("../@db/prop/bot/$bot_id",$data);
return '{"error":"false","description":"Property Setted Successfully"}';
}

}else{

if(file_exists("../@db/prop/usr/$bot_id")){
$data=json_decode(file_get_contents("../@db/prop/usr/$bot_id"),true);
if((filesize("../@db/prop/usr/$bot_id")) > 500000){
return '{ "error":"true", "description":"Cannot Set property max limit reached" }';
}
$data[$chat_id][$name]=$value;
file_put_contents("../@db/prop/usr/$bot_id",$data);
return '{"error":"false","description":"Property Setted Successfully"}';
}else{
$data[$chat_id][$name]=$value;
file_put_contents("../@db/prop/usr/$bot_id",$data);
return '{"error":"false","description":"Property Setted Successfully"}';
}

}
}
public static function getProperty($name,$forUser=false){
adItrb(1);
global $chat_id;
if($forUser == false){
if(file_exists("../@db/prop/bot/$bot_id")){
$data=json_decode(file_get_contents("../@db/prop/bot/$bot_id"),true);
return @$data[$name];
}else{
return;
}
}else{
if(file_exists("../@db/prop/usr/$bot_id")){
$data=json_decode(file_get_contents("../@db/prop/usr/$bot_id"),true);
return @$data[$chat_id][$name];
}else{
return;
}
}
}
public static function sendMessage($message,$datas=[]){
adItrb(1);
global $chat_id;
telegram::action("sendMessage",["chat_id"=>$chat_id,"text"=>$message,"parse_mode"=>"Markdown"]+$datas);
}

public static function sendMessageToChatWithId($id,$message){
adItrb(1);
telegram::action("sendMessage",["chat_id"=>$id,"text"=>$message,"parse_mode"=>"Markdown"]);
}

public static function wafo($command){
adItrb(0);
global $chat_id;
global $bot_id;
file_put_contents("../@db/bots/$bot_id/wfa/$chat_id",$command);
}

public static function sendInlineKeyboard($keyboard,$text){
adItrb(1);
global $chat_id;
$keyboardMarkup = json_encode([
        'inline_keyboard' => $keyboard,
    ]);
    $data = ['chat_id' => $chat_id,'text' => $text,'reply_markup' => $keyboardMarkup,"parse_mode"=>"Markdown"];
    $response = telegram::action("sendMessage",$data);
}

public static function sendInlineKeyboardToChatWithId($id,$keyboard,$text){
adItrb(1);
$keyboardMarkup = json_encode([
        'inline_keyboard' => $keyboard,
    ]);
    $data = ['chat_id' => $id,'text' => $text,'reply_markup' => $keyboardMarkup,"parse_mode"=>"Markdown"];
    $response = telegram::action("sendMessage", $data);
}

public static function sendKeyboard($keyboard,$text){
adItrb(1);
global $chat_id;
$keyboardRows = explode("\n", $keyboard);
    $buttons = [];
    foreach ($keyboardRows as $row) {
        $buttons[] = explode(",", $row);
    }
    $replyMarkup = array(
        'keyboard' => $buttons
    );
    $data = array(
        'chat_id' => $chat_id,
        'text' => $text,
        'reply_markup' => json_encode($replyMarkup),
        "parse_mode"=>"Markdown"
    );
    $response = telegram::action("sendMessage", $data);
}

public static function sendKeyboardToChatWithId($id,$keyboard,$text){
adItrb(1);
global $chat_id;
$keyboardRows = explode("\n", $keyboard);
    $buttons = [];
    foreach ($keyboardRows as $row) {
        $buttons[] = explode(",", $row);
    }
    $replyMarkup = array(
        'keyboard' => $buttons
    );
    $data = array(
        'chat_id' =>$id,
        'text' => $text,
        'reply_markup' => json_encode($replyMarkup),
        "parse_mode"=>"Markdown"
    );
    $response = telegram::action("sendMessage", $data);
}
public static function runCommand($command,$options=[]){
adItrb(1);
global $bot_id;
global $content;
if(strpos($command,"/") !== false){
$cmd=str_replace("/","@",$command);
}else{
$cmd= $command;
}
if(file_exists("../@db/bots/$bot_id/cd1/$cmd")){
include "../@db/bots/$bot_id/cd1/$cmd";
}else{

}
}
}
class Libs {

public static function ReferLib(){
adItrb(5);
if(!class_exists("ReferLib")){
include("ReferLib.php");
}
$referlib= new ReferLib();
return $referlib;
}

public static function Random(){
adItrb(5);
if(!class_exists("Random")){
include("Random.php");
}
$lib= new Random();
return $lib;
}
}
function httpGet($url) {
global $content;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPGET, true);  
  $response = curl_exec($ch);
  if (curl_errno($ch)) {
    $error = curl_error($ch);
    curl_close($ch);
    
  }
  curl_close($ch);
  return $response;
}

?>
<?php
class ReferLib {
public function generateReferLink(){
global $content;
global $chat_id;
$rs=json_decode(httpGet("https://api.telegram.org/bot".$content["token"]."/getMe"), true);;
return "https://t.me/".$rs["result"]["username"]."?start=$chat_id";
}
public function getRefferals($user){
global $bot_id;
$rf=json_decode(file_get_contents("../@db/bots/$bot_id/users/$user"),true);
return $rf["refferals"];
}
public function getRefferalCount($user){
global $bot_id;
$rf=json_decode(file_get_contents("../@db/bots/$bot_id/users/$user"),true);
return count($rf["refferals"]);
}
public function getRefferer($user){
global $bot_id;
$rf=json_decode(file_get_contents("../@db/bots/$bot_id/users/$user"),true);
return $rf["refby"];
}
public function getTopRefferals($amount = 10){
global $bot_id;
$fileData = [];
$files = scandir("../@db/bots/$bot_id/users");
$total=count($files) - 2;
if($amount > $total){
return '{ "error": "true","description":"number of top user requested is greater then total users in bot" }';
}
foreach ($files as $file) {
    if ($file !== '.' && $file !== '..') {
        $fileContent = json_decode(file_get_contents("../@db/bots/$bot_id/users/$file"),true)["refferals"];
        $integerValue = intval($fileContent);
        $file=str_replace(".json","",$file);
        $fileData[$file] = $integerValue;
    }
}
arsort($fileData);
$top= array_slice($fileData, 0,$amount, true);
return $top;
}
}
?>
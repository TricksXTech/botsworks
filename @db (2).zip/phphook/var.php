<?php

     $request=json_decode(file_get_contents("php://input"),true);

     if(isset($request["message"])){
     $chat_id = $request["message"]["chat"]["id"];
     $message_id = $request["message"]["message_id"];
     if(isset($request["message"]["text"])){
     $message = $request["message"]["text"];
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                
     }
     $rdata=$request["message"];
     }
     
     if(isset($request["edited_message"])){
     $chat_id = $request["edited_message"]["chat"]["id"];
     $message_id = $request["edited_message"]["message_id"];
     if(isset($request["edited_message"]["text"])){
     $message = $request["edited_message"]["text"];
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);         
     }else{
     $command= $message;              
     }                
     }
     $rdata=$request["edited_message"];
     }
     
     if(isset($request["channel_post"])){
     $chat_id = $request["channel_post"]["chat"]["id"];
     $message_id = $request["channel_post"]["message_id"];
     if(isset($request["channel_post"]["text"])){
     $message = $request["channel_post"]["text"];
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);         
     }else{
     $command= $message;              
     }                
     }
     $rdata=$request["channel_post"];
     }
     
     if(isset($request["edited_channel_post"])){
     $chat_id = $request["edited_channel_post"]["chat"]["id"];
     $message_id = $request["edited_channel_post"]["message_id"];
     if(isset($request["edited_channel_post"]["text"])){
     $message = $request["edited_channel_post"]["text"];
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);         
     }else{
     $command= $message;              
     }                
     }
     $rdata=$request["edited_channel_post"];
     }
     
     if(isset($request["callback_query"])){
     $chat_id = $request["callback_query"]["from"]["id"];
     $message_id = $request["callback_query"]["inline_message_id"];
     $message = $request["callback_query"]["data"];
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                 
     $rdata=$request["callback_query"];
     }
     
     if(isset($request["inline_query"])){
     $chat_id = $request["inline_query"]["from"]["id"];
     $inline_id = $request["inline_query"]["id"];
     $query = $request["inline_query"]["query"];
     $message="/inlineQuery";
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                 
     $rdata=$request["inline_query"];
     }
     if(isset($request["chosen_inline_result"])){
     $chat_id = $request["chosen_inline_result"]["from"]["id"];
     $result_id = $request["chosen_inline_result"]["result_id"];
     $query = $request["chosen_inline_result"]["query"];
     $message="/chosenInlineResult";
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                 
     $rdata=$request["chosen_inline_result"];
     }
     if(isset($request["shipping_query"])){
     $chat_id = $request["shipping_query"]["from"]["id"];
     $shipping_id = $request["shipping_query"]["id"];
     $message="/shippingQuery";
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                 
     $rdata=$request["shipping_query"];
     }
     if(isset($request["pre_checkout_query"])){
     $chat_id = $request["pre_checkout_query"]["from"]["id"];
     $checkout_id = $request["pre_checkout_query"]["id"];
     $message="/preCheckoutQuery";
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                 
     $rdata=$request["pre_checkout_query"];
     }
     if(isset($request["poll"])){
     $poll_id = $request["poll"]["id"];    
     $message = $request["poll"]["question"];
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                    
     $rdata=$request["poll"];
     }
     if(isset($request["poll_answer"])){
     $poll_id = $request["poll_answer"]["poll_id"];    
     $message = "/pollAnswer";
     $chat_id=$request["poll_answer"]["from"]["id"];
     if(strpos($message,"/") !== false){
     $command=str_replace("/","@",$message);          
     }else{
     $command= $message;               
     }                    
     $rdata=$request["poll_answer"];
     }
     if(isset($request["my_chat_member"])){
     $chat_id=$request["my_chat_member"]["chat"]["id"];
     $user_id=$request["my_chat_member"]["user"]["id"];
     $rdata=$request["my_chat_member"];
     $message="/myChatMember";
     $command="@myChatMember";
     }
     if(isset($request["chat_member"])){
     $chat_id=$request["chat_member"]["chat"]["id"];
     $user_id=$request["chat_member"]["user"]["id"];
     $rdata=$request["chat_member"];
     $message="/chatMember";
     $command="@chatMember";
     }
     if(isset($request["chat_join_request"])){
     $chat_id=$request["chat_join_request"]["chat"]["id"];
     $user_id=$request["chat_join_request"]["from"]["id"];
     $rdata=$request["chat_join_request"];
     $message="/chatJoinRequest";
     $command="@chatJoinRequest";
     }
?>
<?php
class Random {
public function getRandomInt($min=0,$max=10){
return rand($min,$max);
}
public function getRandomFloat($min, $max) {
    return $min + mt_rand() / mt_getrandmax() * ($max - $min);
}
public function getRandomValueFromArray($array) {
    $randomKey = array_rand($array);
    return $array[$randomKey];
}
?>